//
//  myselfbuildTests.swift
//  myselfbuildTests
//
//  Created by Can Yaşa on 2.08.2025.
//

import Testing
@testable import myselfbuild

struct myselfbuildTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
