//
//  ViewController.swift
//  myselfbuild
//
//  Created by Can Yaşa on 2.08.2025.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var items: [String] = []
    

    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return items.count
    }
    func tableView(_ notyeri: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = notyeri.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = items[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle,
                   forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            
            items.remove(at: indexPath.row)
            UserDefaults.standard.set(items, forKey: "gorevler")
            
            tableView.deleteRows(at: [indexPath], with: .fade)
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let cell = tableView.cellForRow(at: indexPath)
        
        
        if cell?.accessoryType == .checkmark {
            cell?.accessoryType = .none
        } else {
            cell?.accessoryType = .checkmark
        }
        
        tableView.deselectRow(at: indexPath, animated: true)
    }



    @IBOutlet weak var notyeri: UITableView!
    @IBOutlet weak var ekle: UIButton!
    @IBOutlet weak var girisAlani: UITextField! 

    
    @IBAction func ekle(_ sender: UIButton) {
        guard let metin = girisAlani.text, !metin.isEmpty else { return }
        
        items.append(metin)
        notyeri.reloadData()
        girisAlani.text = ""
        UserDefaults.standard.set(items, forKey: "gorevler")

        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        notyeri.delegate = self
        notyeri.dataSource = self
        ekle.layer.cornerRadius = 10
        ekle.backgroundColor = .white
        ekle.setTitleColor(.black, for: .normal)
        girisAlani.layer.cornerRadius = 8
        girisAlani.layer.borderColor = UIColor.black.cgColor
        girisAlani.backgroundColor = UIColor.white
        girisAlani.layer.borderWidth = 1
        if let kayitliGorevler = UserDefaults.standard.stringArray(forKey: "gorevler") {
            items = kayitliGorevler
            
        }

        
    }



}

